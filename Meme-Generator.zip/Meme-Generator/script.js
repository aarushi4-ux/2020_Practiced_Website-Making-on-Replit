function meme(img,topText,bottomText,topTextSize,bottomTextSize){
  const canvas = document.getElementById('m-canvas');
  const ctx= canvas.getContext('2d');

  // size canvas to image

  canvas.height= img.height;
  canvas.width= img.width;

  // clear canvas

  ctx.clearRect(0,0,canvas.width,canvas.height);

  // draw main image

  ctx.drawImage(img,0,0);

  // text style

  ctx.fillStyle='blue';
  ctx.strokeStyle='orange';
  ctx.textAlign='center';

  // top text font size

  let fontSize=canvas.width * topTextSize;
  ctx.font= `${fontSize}px Impact`;
  ctx.lineWidth= fontSize/20;

  // top text

  ctx.textBaseline= 'top';
  topText.split('\n').forEach((t,i) => 
  {ctx.fillText(t,canvas.width/2, i*fontSize, canvas.width);
  ctx.strokeText(t,canvas.width/2, i*fontSize, canvas.width);                                   
});

// Bottom text font size

  fontSize=canvas.width * bottomTextSize;
  ctx.font=`${fontSize}px Impact`;
  ctx.lineWidth= fontSize/20;

  // bottom text (reverse() because it is drawing the bottom text from the bottom up)

  ctx.textBaseline='bottom';
  bottomText.split('\n').reverse().forEach((t,i)=> {ctx.fillText(t,canvas.width/2,canvas.height-i*fontSize,canvas.width);
ctx.strokeText(t,canvas.width/2,canvas.height-i*fontSize, canvas.width);                                           
});
}

window.addEventListener('DOMContentLoaded',(event)=> {
  // initialize variables
  const topTextInput= document.getElementById('top-text');
  const bottomTextInput=document.getElementById('bottom-text');
  const topTextSizeInput=document.getElementById('top-text-size-input');
  const bottomTextSizeInput=document.getElementById('bottom-text-size-input');
  const imageInput=document.getElementById('image-input');
  const generateButton=document.getElementById('generate-button');
  // defaultText
  topTextInput.value='Top\nValue';
  bottomTextInput.value='Bottom\nValue';
  generateButton.addEventListener('click', ()=> {
    // read image as data-url using file reader API 
    const reader=new FileReader();
    reader.onload= ()=>{
      const img= new Image;
      img.src=reader.result;
      img.onload=()=>{
        meme(img,topTextInput.value, bottomTextInput.value, topTextSizeInput.value, bottomTextSizeInput.value);
      };
    };
    reader.readAsDataURL(imageInput.files[0]);
  });
});