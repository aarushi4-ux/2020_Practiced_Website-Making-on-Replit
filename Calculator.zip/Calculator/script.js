function calculate(){
  var buttons= document.querySelectorAll("#calculator span");
  var display= document.querySelector("#display");
  var operators= ["+","-","x","/"]
  var decimalAdded= false;
  console.log(buttons);

  var button_value;
  
  for (var i=0; i<buttons.length; i++){
    buttons[i].addEventListener("click", function(){
      button_value=this.innerHTML;

      var displayText=display.innerHTML;

      console.log(displayText)
      
      switch(button_value){
        case 'C':
          display.innerHTML = "";
          decimalAdded = false;
          break;

        case '=':
          var lastChar= displayText[displayText.length-1];
          displayText= displayText.replace("x","*");
          
          if(operators.includes(lastChar) || lastChar=="."){
            break;
          }
            
          else{
            display.innerHTML=eval(displayText)
          }

          decimalAdded=false
          break;

        case '.':
          if (!decimalAdded) {
            display.innerHTML += button_value;
            decimalAdded = true;
          }
          break;

        case '+':
        case '-':
        case 'x':
        case '/':
          var lastChar=displayText[displayText.length-1];
          if(displayText!=""&& !operators.includes(lastChar)){
            display.innerHTML+= button_value;
          }
          else if(displayText==""&& button_value=="-"){
           display.innerHTML+= button_value; 
          }
          
          if(operators.includes(lastChar)&&displayText.length>1){
        display.innerHTML=displayText.replace(lastChar,button_value);
          }
          
          decimalAdded=false
          break;
          
        default: 
          display.textContent+=button_value;
      //display.innerHTML=display.innerHTML+button_value;//
          break;      
      }
    });
  }
}

calculate()