const quizData =[
  {
    question: "In which Italian city can you find the Colosseum?",
    a:"Venice",
    b:"Rome",
    c:"Naples",
    d:"Milan",
    correct:"Rome",
  },
  
  {
    question: "What is the largest canyon in the world?",
    a:"Verdon Gorge, France",
    b:"King’s Canyon, Australia",
    c:"Grand Canyon, USA",
    d:"Fjaðrárgljúfur Canyon, Iceland",
    correct:"Grand Canyon, USA",
  },

  {
    question: "What is the largest active volcano in the world?",
    a:"Mount Etna",
    b:"Mount Vesuvius",
    c:"Mouna Loa",
    d:"Mount Batur",
    correct:"Mouna Loa",
  },

  {
    question: "When was the book “To Kill a Mockingbird” by Harper Lee published?",
    a:"1950",
    b:"1960",
    c:"1970",
    d:"1980",
    correct:"1960",
  },

  {
    question: "Which of the following has introduced text, list, box, margin, border, color, and background properties?",
    a:"HTML",
    b:"PHP",
    c:"Ajax",
    d:"CSS",
    correct:"CSS",
  },

  {
   question: "When did Hitler invade Poland?",
    a:"1st September 1939",
    b:"11th November 1939",
    c:"8th May 1940",
    d:"1st December 1940",
    correct:"1st September 1939", 
  },

  {
    question: "Which famous inventor invented the telephone?",
    a:"Thomas Edison",
    b:"Benjamin Franklin",
    c:"Alexander Graham Bell",
    d:"Nikola Tesla",
    correct:"Alexander Graham Bell",
  },
  
  {
    question: "When was the first Harry Potter book published?",
    a:"1997",
    b:"1999",
    c:"2001",
    d:"2003",
    correct:"1997",
  },
] ;

const quiz=document.getElementById('quiz')
const answerEls=document.querySelectorAll('.answer')
const questionEl=document.getElementById('question')
const a_text=document.getElementById('a_text')
const b_text=document.getElementById('b_text')
const c_text=document.getElementById('c_text')
const d_text=document.getElementById('d_text')
const submitButton=document.getElementById('submit')

let currentQuiz=0 
let score= 0

loadQuiz()

function loadQuiz(){
  deselectAnswers()
  const currentQuizData=quizData[currentQuiz]
  questionEl.innerText=currentQuizData.question
  a_text.innerText=currentQuizData.a
  b_text.innerText=currentQuizData.b
  c_text.innerText=currentQuizData.c
  d_text.innerText=currentQuizData.d
}

function deselectAnswers(){
  answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected(){
  let answer
  answerEls.forEach(answerEl => {
    if(answerEl.checked){
      answer=answerEl.id
    }
  })
  return answer
}

submitButton.addEventListener('click', () => {
  const answer = getSelected()
  if(answer){
    if(answer === quizData[currentQuiz].correct){
      score = score + 1
    }
    
    currentQuiz++

    if(currentQuiz < quizData.length){
      loadQuiz()
    }
    else{
      quiz.innerHTML=`
        <h2>You answered ${score}/${quizData.length} questions correctly</h2>
        <button onclick="location.reload()">Reload</button>
        `
    }
  }
})